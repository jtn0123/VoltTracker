--
-- PostgreSQL database dump
--

-- Dumped from database version 15.13
-- Dumped by pg_dump version 15.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: timescaledb; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS timescaledb WITH SCHEMA public;


--
-- Name: EXTENSION timescaledb; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION timescaledb IS 'Enables scalable inserts and complex queries for time-series data (Community Edition)';


--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: volt
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO volt;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _compressed_hypertable_2; Type: TABLE; Schema: _timescaledb_internal; Owner: volt
--

CREATE TABLE _timescaledb_internal._compressed_hypertable_2 (
);


ALTER TABLE _timescaledb_internal._compressed_hypertable_2 OWNER TO volt;

--
-- Name: battery_health_readings; Type: TABLE; Schema: public; Owner: volt
--

CREATE TABLE public.battery_health_readings (
    id integer NOT NULL,
    "timestamp" timestamp with time zone NOT NULL,
    capacity_kwh double precision,
    normalized_capacity_kwh double precision,
    soc_at_reading double precision,
    ambient_temp_f double precision,
    odometer_miles double precision,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.battery_health_readings OWNER TO volt;

--
-- Name: battery_health_readings_id_seq; Type: SEQUENCE; Schema: public; Owner: volt
--

CREATE SEQUENCE public.battery_health_readings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.battery_health_readings_id_seq OWNER TO volt;

--
-- Name: battery_health_readings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: volt
--

ALTER SEQUENCE public.battery_health_readings_id_seq OWNED BY public.battery_health_readings.id;


--
-- Name: charging_sessions; Type: TABLE; Schema: public; Owner: volt
--

CREATE TABLE public.charging_sessions (
    id integer NOT NULL,
    start_time timestamp with time zone NOT NULL,
    end_time timestamp with time zone,
    start_soc numeric(5,2),
    end_soc numeric(5,2),
    kwh_added numeric(6,2),
    peak_power_kw numeric(6,2),
    avg_power_kw numeric(6,2),
    latitude numeric(9,6),
    longitude numeric(9,6),
    location_name character varying(255),
    charge_type character varying(50),
    cost numeric(6,2),
    cost_per_kwh numeric(6,4),
    electricity_rate double precision,
    notes text,
    is_complete boolean DEFAULT false,
    charging_curve jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.charging_sessions OWNER TO volt;

--
-- Name: charging_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: volt
--

CREATE SEQUENCE public.charging_sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.charging_sessions_id_seq OWNER TO volt;

--
-- Name: charging_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: volt
--

ALTER SEQUENCE public.charging_sessions_id_seq OWNED BY public.charging_sessions.id;


--
-- Name: fuel_events; Type: TABLE; Schema: public; Owner: volt
--

CREATE TABLE public.fuel_events (
    id integer NOT NULL,
    "timestamp" timestamp with time zone NOT NULL,
    odometer_miles numeric(10,1),
    gallons_added numeric(4,2),
    fuel_level_before numeric(5,2),
    fuel_level_after numeric(5,2),
    price_per_gallon numeric(4,3),
    total_cost numeric(6,2),
    notes text,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.fuel_events OWNER TO volt;

--
-- Name: fuel_events_id_seq; Type: SEQUENCE; Schema: public; Owner: volt
--

CREATE SEQUENCE public.fuel_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.fuel_events_id_seq OWNER TO volt;

--
-- Name: fuel_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: volt
--

ALTER SEQUENCE public.fuel_events_id_seq OWNED BY public.fuel_events.id;


--
-- Name: soc_transitions; Type: TABLE; Schema: public; Owner: volt
--

CREATE TABLE public.soc_transitions (
    id integer NOT NULL,
    trip_id integer,
    "timestamp" timestamp with time zone NOT NULL,
    soc_at_transition numeric(5,2),
    ambient_temp_f numeric(5,1),
    odometer_miles numeric(10,1),
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.soc_transitions OWNER TO volt;

--
-- Name: soc_transitions_id_seq; Type: SEQUENCE; Schema: public; Owner: volt
--

CREATE SEQUENCE public.soc_transitions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.soc_transitions_id_seq OWNER TO volt;

--
-- Name: soc_transitions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: volt
--

ALTER SEQUENCE public.soc_transitions_id_seq OWNED BY public.soc_transitions.id;


--
-- Name: telemetry_raw; Type: TABLE; Schema: public; Owner: volt
--

CREATE TABLE public.telemetry_raw (
    id bigint NOT NULL,
    session_id uuid NOT NULL,
    "timestamp" timestamp with time zone NOT NULL,
    latitude numeric(9,6),
    longitude numeric(9,6),
    speed_mph numeric(5,1),
    engine_rpm numeric(6,1),
    throttle_position numeric(5,2),
    coolant_temp_f numeric(5,1),
    intake_air_temp_f numeric(5,1),
    fuel_level_percent numeric(5,2),
    fuel_remaining_gallons numeric(4,2),
    state_of_charge numeric(5,2),
    battery_voltage numeric(5,2),
    ambient_temp_f numeric(5,1),
    odometer_miles numeric(10,1),
    hv_battery_power_kw numeric(6,2),
    hv_battery_current_a numeric(6,2),
    hv_battery_voltage_v numeric(6,2),
    charger_ac_power_kw numeric(6,2),
    charger_connected boolean,
    hv_discharge_amps double precision,
    battery_temp_f double precision,
    battery_coolant_temp_f double precision,
    charger_status double precision,
    charger_power_kw double precision,
    charger_power_w double precision,
    charger_ac_voltage double precision,
    charger_ac_current double precision,
    charger_hv_voltage double precision,
    charger_hv_current double precision,
    last_charge_wh double precision,
    motor_a_rpm double precision,
    motor_b_rpm double precision,
    generator_rpm double precision,
    motor_temp_max_f double precision,
    engine_oil_temp_f double precision,
    engine_torque_nm double precision,
    engine_running boolean,
    transmission_temp_f double precision,
    battery_capacity_kwh double precision,
    lifetime_ev_miles double precision,
    lifetime_gas_miles double precision,
    lifetime_fuel_gal double precision,
    lifetime_kwh double precision,
    dte_electric_miles double precision,
    dte_gas_miles double precision,
    raw_data jsonb,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.telemetry_raw OWNER TO volt;

--
-- Name: telemetry_raw_id_seq; Type: SEQUENCE; Schema: public; Owner: volt
--

CREATE SEQUENCE public.telemetry_raw_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.telemetry_raw_id_seq OWNER TO volt;

--
-- Name: telemetry_raw_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: volt
--

ALTER SEQUENCE public.telemetry_raw_id_seq OWNED BY public.telemetry_raw.id;


--
-- Name: trips; Type: TABLE; Schema: public; Owner: volt
--

CREATE TABLE public.trips (
    id integer NOT NULL,
    session_id uuid NOT NULL,
    start_time timestamp with time zone NOT NULL,
    end_time timestamp with time zone,
    start_odometer numeric(10,1),
    end_odometer numeric(10,1),
    distance_miles numeric(6,1),
    start_soc numeric(5,2),
    soc_at_gas_transition numeric(5,2),
    electric_miles numeric(6,1),
    electric_kwh_used numeric(6,2),
    kwh_per_mile numeric(6,3),
    gas_mode_entered boolean DEFAULT false,
    gas_mode_entry_time timestamp with time zone,
    gas_miles numeric(6,1),
    fuel_used_gallons numeric(4,2),
    gas_mpg numeric(5,1),
    fuel_level_at_gas_entry numeric(5,2),
    fuel_level_at_end numeric(5,2),
    ambient_temp_avg_f numeric(5,1),
    is_closed boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    weather_temp_f numeric(5,1),
    weather_precipitation_in numeric(5,3),
    weather_wind_mph numeric(5,1),
    weather_conditions character varying(50),
    weather_impact_factor numeric(4,3),
    is_imported boolean DEFAULT false,
    deleted_at timestamp with time zone
);


ALTER TABLE public.trips OWNER TO volt;

--
-- Name: trips_id_seq; Type: SEQUENCE; Schema: public; Owner: volt
--

CREATE SEQUENCE public.trips_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.trips_id_seq OWNER TO volt;

--
-- Name: trips_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: volt
--

ALTER SEQUENCE public.trips_id_seq OWNED BY public.trips.id;


--
-- Name: battery_health_readings id; Type: DEFAULT; Schema: public; Owner: volt
--

ALTER TABLE ONLY public.battery_health_readings ALTER COLUMN id SET DEFAULT nextval('public.battery_health_readings_id_seq'::regclass);


--
-- Name: charging_sessions id; Type: DEFAULT; Schema: public; Owner: volt
--

ALTER TABLE ONLY public.charging_sessions ALTER COLUMN id SET DEFAULT nextval('public.charging_sessions_id_seq'::regclass);


--
-- Name: fuel_events id; Type: DEFAULT; Schema: public; Owner: volt
--

ALTER TABLE ONLY public.fuel_events ALTER COLUMN id SET DEFAULT nextval('public.fuel_events_id_seq'::regclass);


--
-- Name: soc_transitions id; Type: DEFAULT; Schema: public; Owner: volt
--

ALTER TABLE ONLY public.soc_transitions ALTER COLUMN id SET DEFAULT nextval('public.soc_transitions_id_seq'::regclass);


--
-- Name: telemetry_raw id; Type: DEFAULT; Schema: public; Owner: volt
--

ALTER TABLE ONLY public.telemetry_raw ALTER COLUMN id SET DEFAULT nextval('public.telemetry_raw_id_seq'::regclass);


--
-- Name: trips id; Type: DEFAULT; Schema: public; Owner: volt
--

ALTER TABLE ONLY public.trips ALTER COLUMN id SET DEFAULT nextval('public.trips_id_seq'::regclass);


--
-- Data for Name: hypertable; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: volt
--

COPY _timescaledb_catalog.hypertable (id, schema_name, table_name, associated_schema_name, associated_table_prefix, num_dimensions, chunk_sizing_func_schema, chunk_sizing_func_name, chunk_target_size, compression_state, compressed_hypertable_id, status) FROM stdin;
2	_timescaledb_internal	_compressed_hypertable_2	_timescaledb_internal	_hyper_2	0	_timescaledb_functions	calculate_chunk_interval	0	2	\N	0
1	public	telemetry_raw	_timescaledb_internal	_hyper_1	1	_timescaledb_functions	calculate_chunk_interval	0	1	2	0
\.


--
-- Data for Name: chunk; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: volt
--

COPY _timescaledb_catalog.chunk (id, hypertable_id, schema_name, table_name, compressed_chunk_id, dropped, status, osm_chunk, creation_time) FROM stdin;
\.


--
-- Data for Name: chunk_column_stats; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: volt
--

COPY _timescaledb_catalog.chunk_column_stats (id, hypertable_id, chunk_id, column_name, range_start, range_end, valid) FROM stdin;
\.


--
-- Data for Name: dimension; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: volt
--

COPY _timescaledb_catalog.dimension (id, hypertable_id, column_name, column_type, aligned, num_slices, partitioning_func_schema, partitioning_func, interval_length, compress_interval_length, integer_now_func_schema, integer_now_func) FROM stdin;
1	1	timestamp	timestamp with time zone	t	\N	\N	\N	86400000000	\N	\N	\N
\.


--
-- Data for Name: dimension_slice; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: volt
--

COPY _timescaledb_catalog.dimension_slice (id, dimension_id, range_start, range_end) FROM stdin;
\.


--
-- Data for Name: chunk_constraint; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: volt
--

COPY _timescaledb_catalog.chunk_constraint (chunk_id, dimension_slice_id, constraint_name, hypertable_constraint_name) FROM stdin;
\.


--
-- Data for Name: compression_chunk_size; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: volt
--

COPY _timescaledb_catalog.compression_chunk_size (chunk_id, compressed_chunk_id, uncompressed_heap_size, uncompressed_toast_size, uncompressed_index_size, compressed_heap_size, compressed_toast_size, compressed_index_size, numrows_pre_compression, numrows_post_compression, numrows_frozen_immediately) FROM stdin;
\.


--
-- Data for Name: compression_settings; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: volt
--

COPY _timescaledb_catalog.compression_settings (relid, compress_relid, segmentby, orderby, orderby_desc, orderby_nullsfirst, index) FROM stdin;
public.telemetry_raw	\N	{session_id}	\N	\N	\N	\N
\.


--
-- Data for Name: continuous_agg; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: volt
--

COPY _timescaledb_catalog.continuous_agg (mat_hypertable_id, raw_hypertable_id, parent_mat_hypertable_id, user_view_schema, user_view_name, partial_view_schema, partial_view_name, direct_view_schema, direct_view_name, materialized_only, finalized) FROM stdin;
\.


--
-- Data for Name: continuous_agg_migrate_plan; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: volt
--

COPY _timescaledb_catalog.continuous_agg_migrate_plan (mat_hypertable_id, start_ts, end_ts, user_view_definition) FROM stdin;
\.


--
-- Data for Name: continuous_agg_migrate_plan_step; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: volt
--

COPY _timescaledb_catalog.continuous_agg_migrate_plan_step (mat_hypertable_id, step_id, status, start_ts, end_ts, type, config) FROM stdin;
\.


--
-- Data for Name: continuous_aggs_bucket_function; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: volt
--

COPY _timescaledb_catalog.continuous_aggs_bucket_function (mat_hypertable_id, bucket_func, bucket_width, bucket_origin, bucket_offset, bucket_timezone, bucket_fixed_width) FROM stdin;
\.


--
-- Data for Name: continuous_aggs_hypertable_invalidation_log; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: volt
--

COPY _timescaledb_catalog.continuous_aggs_hypertable_invalidation_log (hypertable_id, lowest_modified_value, greatest_modified_value) FROM stdin;
\.


--
-- Data for Name: continuous_aggs_invalidation_threshold; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: volt
--

COPY _timescaledb_catalog.continuous_aggs_invalidation_threshold (hypertable_id, watermark) FROM stdin;
\.


--
-- Data for Name: continuous_aggs_materialization_invalidation_log; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: volt
--

COPY _timescaledb_catalog.continuous_aggs_materialization_invalidation_log (materialization_id, lowest_modified_value, greatest_modified_value) FROM stdin;
\.


--
-- Data for Name: continuous_aggs_materialization_ranges; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: volt
--

COPY _timescaledb_catalog.continuous_aggs_materialization_ranges (materialization_id, lowest_modified_value, greatest_modified_value) FROM stdin;
\.


--
-- Data for Name: continuous_aggs_watermark; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: volt
--

COPY _timescaledb_catalog.continuous_aggs_watermark (mat_hypertable_id, watermark) FROM stdin;
\.


--
-- Data for Name: metadata; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: volt
--

COPY _timescaledb_catalog.metadata (key, value, include_in_telemetry) FROM stdin;
install_timestamp	2025-12-31 05:26:33.410215+00	t
timescaledb_version	2.24.0	f
exported_uuid	ed0fe942-0af8-44f7-b75e-1fc3e5bb901f	t
\.


--
-- Data for Name: tablespace; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: volt
--

COPY _timescaledb_catalog.tablespace (id, hypertable_id, tablespace_name) FROM stdin;
\.


--
-- Data for Name: bgw_job; Type: TABLE DATA; Schema: _timescaledb_config; Owner: volt
--

COPY _timescaledb_config.bgw_job (id, application_name, schedule_interval, max_runtime, max_retries, retry_period, proc_schema, proc_name, owner, scheduled, fixed_schedule, initial_start, hypertable_id, config, check_schema, check_name, timezone) FROM stdin;
1000	Columnstore Policy [1000]	12:00:00	00:00:00	-1	01:00:00	_timescaledb_functions	policy_compression	volt	t	f	\N	1	{"hypertable_id": 1, "compress_after": "7 days"}	_timescaledb_functions	policy_compression_check	\N
\.


--
-- Data for Name: _compressed_hypertable_2; Type: TABLE DATA; Schema: _timescaledb_internal; Owner: volt
--

COPY _timescaledb_internal._compressed_hypertable_2  FROM stdin;
\.


--
-- Data for Name: battery_health_readings; Type: TABLE DATA; Schema: public; Owner: volt
--

COPY public.battery_health_readings (id, "timestamp", capacity_kwh, normalized_capacity_kwh, soc_at_reading, ambient_temp_f, odometer_miles, created_at) FROM stdin;
\.


--
-- Data for Name: charging_sessions; Type: TABLE DATA; Schema: public; Owner: volt
--

COPY public.charging_sessions (id, start_time, end_time, start_soc, end_soc, kwh_added, peak_power_kw, avg_power_kw, latitude, longitude, location_name, charge_type, cost, cost_per_kwh, electricity_rate, notes, is_complete, charging_curve, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: fuel_events; Type: TABLE DATA; Schema: public; Owner: volt
--

COPY public.fuel_events (id, "timestamp", odometer_miles, gallons_added, fuel_level_before, fuel_level_after, price_per_gallon, total_cost, notes, created_at) FROM stdin;
\.


--
-- Data for Name: soc_transitions; Type: TABLE DATA; Schema: public; Owner: volt
--

COPY public.soc_transitions (id, trip_id, "timestamp", soc_at_transition, ambient_temp_f, odometer_miles, created_at) FROM stdin;
\.


--
-- Data for Name: telemetry_raw; Type: TABLE DATA; Schema: public; Owner: volt
--

COPY public.telemetry_raw (id, session_id, "timestamp", latitude, longitude, speed_mph, engine_rpm, throttle_position, coolant_temp_f, intake_air_temp_f, fuel_level_percent, fuel_remaining_gallons, state_of_charge, battery_voltage, ambient_temp_f, odometer_miles, hv_battery_power_kw, hv_battery_current_a, hv_battery_voltage_v, charger_ac_power_kw, charger_connected, hv_discharge_amps, battery_temp_f, battery_coolant_temp_f, charger_status, charger_power_kw, charger_power_w, charger_ac_voltage, charger_ac_current, charger_hv_voltage, charger_hv_current, last_charge_wh, motor_a_rpm, motor_b_rpm, generator_rpm, motor_temp_max_f, engine_oil_temp_f, engine_torque_nm, engine_running, transmission_temp_f, battery_capacity_kwh, lifetime_ev_miles, lifetime_gas_miles, lifetime_fuel_gal, lifetime_kwh, dte_electric_miles, dte_gas_miles, raw_data, created_at) FROM stdin;
\.


--
-- Data for Name: trips; Type: TABLE DATA; Schema: public; Owner: volt
--

COPY public.trips (id, session_id, start_time, end_time, start_odometer, end_odometer, distance_miles, start_soc, soc_at_gas_transition, electric_miles, electric_kwh_used, kwh_per_mile, gas_mode_entered, gas_mode_entry_time, gas_miles, fuel_used_gallons, gas_mpg, fuel_level_at_gas_entry, fuel_level_at_end, ambient_temp_avg_f, is_closed, created_at, updated_at, weather_temp_f, weather_precipitation_in, weather_wind_mph, weather_conditions, weather_impact_factor, is_imported, deleted_at) FROM stdin;
\.


--
-- Name: chunk_column_stats_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: volt
--

SELECT pg_catalog.setval('_timescaledb_catalog.chunk_column_stats_id_seq', 1, false);


--
-- Name: chunk_constraint_name; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: volt
--

SELECT pg_catalog.setval('_timescaledb_catalog.chunk_constraint_name', 1, false);


--
-- Name: chunk_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: volt
--

SELECT pg_catalog.setval('_timescaledb_catalog.chunk_id_seq', 1, false);


--
-- Name: continuous_agg_migrate_plan_step_step_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: volt
--

SELECT pg_catalog.setval('_timescaledb_catalog.continuous_agg_migrate_plan_step_step_id_seq', 1, false);


--
-- Name: dimension_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: volt
--

SELECT pg_catalog.setval('_timescaledb_catalog.dimension_id_seq', 1, true);


--
-- Name: dimension_slice_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: volt
--

SELECT pg_catalog.setval('_timescaledb_catalog.dimension_slice_id_seq', 1, false);


--
-- Name: hypertable_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: volt
--

SELECT pg_catalog.setval('_timescaledb_catalog.hypertable_id_seq', 2, true);


--
-- Name: bgw_job_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_config; Owner: volt
--

SELECT pg_catalog.setval('_timescaledb_config.bgw_job_id_seq', 1000, true);


--
-- Name: battery_health_readings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: volt
--

SELECT pg_catalog.setval('public.battery_health_readings_id_seq', 1, false);


--
-- Name: charging_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: volt
--

SELECT pg_catalog.setval('public.charging_sessions_id_seq', 1, false);


--
-- Name: fuel_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: volt
--

SELECT pg_catalog.setval('public.fuel_events_id_seq', 1, false);


--
-- Name: soc_transitions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: volt
--

SELECT pg_catalog.setval('public.soc_transitions_id_seq', 1, false);


--
-- Name: telemetry_raw_id_seq; Type: SEQUENCE SET; Schema: public; Owner: volt
--

SELECT pg_catalog.setval('public.telemetry_raw_id_seq', 1, false);


--
-- Name: trips_id_seq; Type: SEQUENCE SET; Schema: public; Owner: volt
--

SELECT pg_catalog.setval('public.trips_id_seq', 1, false);


--
-- Name: battery_health_readings battery_health_readings_pkey; Type: CONSTRAINT; Schema: public; Owner: volt
--

ALTER TABLE ONLY public.battery_health_readings
    ADD CONSTRAINT battery_health_readings_pkey PRIMARY KEY (id);


--
-- Name: charging_sessions charging_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: volt
--

ALTER TABLE ONLY public.charging_sessions
    ADD CONSTRAINT charging_sessions_pkey PRIMARY KEY (id);


--
-- Name: fuel_events fuel_events_pkey; Type: CONSTRAINT; Schema: public; Owner: volt
--

ALTER TABLE ONLY public.fuel_events
    ADD CONSTRAINT fuel_events_pkey PRIMARY KEY (id);


--
-- Name: soc_transitions soc_transitions_pkey; Type: CONSTRAINT; Schema: public; Owner: volt
--

ALTER TABLE ONLY public.soc_transitions
    ADD CONSTRAINT soc_transitions_pkey PRIMARY KEY (id);


--
-- Name: telemetry_raw telemetry_raw_pkey; Type: CONSTRAINT; Schema: public; Owner: volt
--

ALTER TABLE ONLY public.telemetry_raw
    ADD CONSTRAINT telemetry_raw_pkey PRIMARY KEY (id, "timestamp");


--
-- Name: trips trips_pkey; Type: CONSTRAINT; Schema: public; Owner: volt
--

ALTER TABLE ONLY public.trips
    ADD CONSTRAINT trips_pkey PRIMARY KEY (id);


--
-- Name: trips trips_session_id_key; Type: CONSTRAINT; Schema: public; Owner: volt
--

ALTER TABLE ONLY public.trips
    ADD CONSTRAINT trips_session_id_key UNIQUE (session_id);


--
-- Name: idx_battery_health_timestamp; Type: INDEX; Schema: public; Owner: volt
--

CREATE INDEX idx_battery_health_timestamp ON public.battery_health_readings USING btree ("timestamp");


--
-- Name: idx_charging_sessions_is_complete; Type: INDEX; Schema: public; Owner: volt
--

CREATE INDEX idx_charging_sessions_is_complete ON public.charging_sessions USING btree (is_complete);


--
-- Name: idx_charging_sessions_start_time; Type: INDEX; Schema: public; Owner: volt
--

CREATE INDEX idx_charging_sessions_start_time ON public.charging_sessions USING btree (start_time);


--
-- Name: idx_fuel_events_timestamp; Type: INDEX; Schema: public; Owner: volt
--

CREATE INDEX idx_fuel_events_timestamp ON public.fuel_events USING btree ("timestamp");


--
-- Name: idx_soc_transitions_timestamp; Type: INDEX; Schema: public; Owner: volt
--

CREATE INDEX idx_soc_transitions_timestamp ON public.soc_transitions USING btree ("timestamp");


--
-- Name: idx_telemetry_rpm; Type: INDEX; Schema: public; Owner: volt
--

CREATE INDEX idx_telemetry_rpm ON public.telemetry_raw USING btree (engine_rpm);


--
-- Name: idx_telemetry_session; Type: INDEX; Schema: public; Owner: volt
--

CREATE INDEX idx_telemetry_session ON public.telemetry_raw USING btree (session_id);


--
-- Name: idx_telemetry_soc; Type: INDEX; Schema: public; Owner: volt
--

CREATE INDEX idx_telemetry_soc ON public.telemetry_raw USING btree (state_of_charge);


--
-- Name: idx_telemetry_timestamp; Type: INDEX; Schema: public; Owner: volt
--

CREATE INDEX idx_telemetry_timestamp ON public.telemetry_raw USING btree ("timestamp");


--
-- Name: idx_trips_deleted_at; Type: INDEX; Schema: public; Owner: volt
--

CREATE INDEX idx_trips_deleted_at ON public.trips USING btree (deleted_at);


--
-- Name: idx_trips_gas_mode; Type: INDEX; Schema: public; Owner: volt
--

CREATE INDEX idx_trips_gas_mode ON public.trips USING btree (gas_mode_entered);


--
-- Name: idx_trips_is_closed; Type: INDEX; Schema: public; Owner: volt
--

CREATE INDEX idx_trips_is_closed ON public.trips USING btree (is_closed);


--
-- Name: idx_trips_is_imported; Type: INDEX; Schema: public; Owner: volt
--

CREATE INDEX idx_trips_is_imported ON public.trips USING btree (is_imported);


--
-- Name: idx_trips_start_time; Type: INDEX; Schema: public; Owner: volt
--

CREATE INDEX idx_trips_start_time ON public.trips USING btree (start_time);


--
-- Name: idx_trips_weather_conditions; Type: INDEX; Schema: public; Owner: volt
--

CREATE INDEX idx_trips_weather_conditions ON public.trips USING btree (weather_conditions);


--
-- Name: idx_trips_weather_temp; Type: INDEX; Schema: public; Owner: volt
--

CREATE INDEX idx_trips_weather_temp ON public.trips USING btree (weather_temp_f);


--
-- Name: charging_sessions update_charging_sessions_updated_at; Type: TRIGGER; Schema: public; Owner: volt
--

CREATE TRIGGER update_charging_sessions_updated_at BEFORE UPDATE ON public.charging_sessions FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: trips update_trips_updated_at; Type: TRIGGER; Schema: public; Owner: volt
--

CREATE TRIGGER update_trips_updated_at BEFORE UPDATE ON public.trips FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: soc_transitions soc_transitions_trip_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: volt
--

ALTER TABLE ONLY public.soc_transitions
    ADD CONSTRAINT soc_transitions_trip_id_fkey FOREIGN KEY (trip_id) REFERENCES public.trips(id);


--
-- PostgreSQL database dump complete
--

